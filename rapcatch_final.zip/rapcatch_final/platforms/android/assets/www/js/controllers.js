var app = angular.module('starter.controllers', ['ngSanitize'])

app.controller('AppCtrl', function($scope, $ionicModal, $ionicLoading,$sce) {
  // var detail;
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.viewMode = 'all';

  $scope.changeView = function(mode){
    $scope.viewMode = mode;
  }
  $scope.loadWeb = function(url) {
    console.log('loadWeb');
    $scope.changeView('one');
    $scope.webUrl = $sce.trustAsResourceUrl(url);
  }

  $scope.New = function(){
     alert("OK");
 //   $scope.loadWeb('http://rapcatchup.wpengine.com/category/videos/');
  }

  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  //logout
  $scope.logout = function() {
    $ionicLoading.show();
     $.ajax({
      url: "http://46.105.31.33/page-mobile-api.php",
      type: "post",
      data: {
        mobile_api_function:"logout"
      },
      dataType: 'html',
      success: function (response) {
        console.log(response);
        var object = JSON.parse(response);
        if(object=='success') {
          window.localStorage.setItem("CurrentUser", null);
          window.localStorage.setItem("loggedin", 'false');
          $ionicLoading.hide();
          window.location.href = "index.html";
        }else{
          alert("Login failed! Please check your credentials!");
        }
      },
      error: function(jqXHR, textStatus, errorThrown) {
         console.log(textStatus, errorThrown);
      }
    });
    };

  // Perform the login action when the user submits the login form

})

app.controller('PlaylistsCtrl', function($scope, $sce, $ionicLoading) {
  $scope.getPostDetail = function(id){
    $.ajax({
          url: "http://rapcatchup.wpengine.com/api/get_post/",
          type: "get",
          data: {
            'post_id': id
          },
          dataType: 'html',
          success: function (response) {
          var object = JSON.parse(response);  
          console.log(object.object);

          detail = object;
          console.log(detail);

          window.location.href = '#/app/postdetail';

          },
      error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);

      }
    });
  }

  //loading page
   $scope.showloading = function() {
    $ionicLoading.show({
      noBackdrop: true,
      template:'<p class="item-icon-left">Loading...<ion-spinner icon="ios"/></p>'
    });
  };
  $scope.hideloading = function(){
    $ionicLoading.hide();
  };

  //iframe
  $scope.viewMode = 'all';

  $scope.changeView = function(mode){
    $scope.viewMode = mode;
  }
  $scope.loadWeb = function(url) {
    console.log('loadWeb');
    $scope.changeView('one');
    $scope.webUrl = $sce.trustAsResourceUrl(url);
  }
    
    $scope.showloading();
            $.ajax({
                  url: "http://46.105.31.33/page-mobile-api.php",
                  type: "post",
                  data: {
                    'mobile_api_function':"get_post"
                  },
                  dataType: 'html',
                  success: function (response) {

                  var object = JSON.parse(response);
                  
                  $scope.entries = object.posts;
                   console.log($scope.entries);
                  $ionicLoading.hide();
                  $scope.data = $scope.entries.slice(0, 10);
                  console.log("abc");
                   console.log($scope.data);
                  },
              error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
              }
            });    
                   $scope.getMoreData = function () {
                    $scope.showloading();
                    $scope.data = $scope.entries.slice(0, $scope.data.length + 10);
                    $scope.hideloading();
                     }

  })

app.controller('ProfileCtrl', function($scope) {
   $('#username').val(localStorage.getItem('CurrentUser'));
   $('#first_name').val(localStorage.getItem('firstname'));
   $('#last_name').val(localStorage.getItem('lastname'));
   $('#email').val(localStorage.getItem('email'));
   $('#nickname').val(localStorage.getItem('nickname'));
   $('#displayname').val(localStorage.getItem('displayname'));
 })
.controller('AboutCtrl', function($scope) {

 })
app.controller('PostdetailCtrl', function($scope, $sce) {
          // console.log(detail.post);
    $scope.detail_post = detail.post;
    console.log($scope.detail_post);
    $scope.ytUrl = $sce.trustAsResourceUrl('http://www.youtube.com/embed/'+$scope.detail_post.custom_fields.yvtwp_video_key[0]);
    console.log($scope.detail_post.thumbnail_images.full.url); 
   $scope.viewMode = 'all';

  $scope.changeView = function(mode){
    $scope.viewMode = mode;
  }
  $scope.loadWeb = function(url) {
    console.log('loadWeb');
    $scope.changeView('one');
    $scope.webUrl = $sce.trustAsResourceUrl(url);
  }
 })

 app.controller('NewCtrl', function($scope,$sce, $ionicLoading) {

  $scope.getPostDetail = function(id){

    $.ajax({
          url: "http://rapcatchup.wpengine.com/api/get_post/",
          type: "get",
          data: {
             'post_id': id
          },
          dataType: 'html',
          success: function (response) {
          var object = JSON.parse(response);
          console.log('object');
          
          detail = object;
          console.log(detail);

          window.location.href = '#/app/postdetail';

          },
      error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);

      }
    });
  }

   $scope.showloading = function() {
    $ionicLoading.show({
      noBackdrop: true,
      template:'<p class="item-icon-left">Loading...<ion-spinner icon="ios"/></p>'
    });
  };

  $scope.hideloading = function(){
    $ionicLoading.hide();
  };

   //browseinapp
  $scope.viewMode = 'all';

  $scope.changeView = function(mode){
    $scope.viewMode = mode;
    // window.location.href("playlists.html");
  }
  $scope.loadWeb = function(url) {
    console.log('loadWeb');
    $scope.changeView('one');
    $scope.webUrl = $sce.trustAsResourceUrl(url);
  }

  $scope.showloading();
            $.ajax({
                  url: "http://46.105.31.33/page-mobile-api.php",
                  type: "post",
                  data: {
                    'mobile_api_function':"get_post_news"
                  },
                  dataType: 'html',
                  success: function (response) {

                  var object = JSON.parse(response);
                  $scope.news = object.posts;
                  console.log($scope.news);
                  $ionicLoading.hide();
                  $scope.data = $scope.news.slice(0, 10);
                  console.log("abc");
                  console.log($scope.data);
                  },
              error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
              }
            });

            $scope.getMoreData = function () {
                    // alert("aa");
                    $scope.showloading();
                    $scope.data = $scope.news.slice(0, $scope.data.length + 10);
                    // $scope.$apply('data');
                    $scope.hideloading();
                     }



 })

 app.controller('MusicCtrl', function($scope,$sce, $ionicLoading) {

  $scope.getPostDetail = function(id){

    $.ajax({
          url: "http://rapcatchup.wpengine.com/api/get_post/",
          type: "get",
          data: {
             'post_id': id
          },
          dataType: 'html',
          success: function (response) {
          var object = JSON.parse(response);
          console.log('object');
          
          detail = object;
          console.log(detail);

          window.location.href = '#/app/postdetail';

          },
      error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);

      }
    });
  }

   $scope.showloading = function() {
    $ionicLoading.show({
      noBackdrop: true,
      template:'<p class="item-icon-left">Loading...<ion-spinner icon="ios"/></p>'
    });
  };

  $scope.hideloading = function(){
    $ionicLoading.hide();
  };

   //browseinapp
  $scope.viewMode = 'all';

  $scope.changeView = function(mode){
    $scope.viewMode = mode;
 
  }
  $scope.loadWeb = function(url) {
    console.log('loadWeb');
    $scope.changeView('one');
    $scope.webUrl = $sce.trustAsResourceUrl(url);
  }

  $scope.showloading();
            $.ajax({
                  url: "http://46.105.31.33/page-mobile-api.php",
                  type: "post",
                  data: {
                    'mobile_api_function':"get_post_music"
                  },
                  dataType: 'html',
                  success: function (response) {

                  var object = JSON.parse(response);
                  $scope.musics = object.posts;
                  console.log($scope.musics);
                  $ionicLoading.hide();
                  $scope.data = $scope.musics.slice(0, 10);
                  console.log("abc");
                  console.log($scope.data);
                  },
              error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
              }
            });

            $scope.getMoreData = function () {
                    // alert("aa");
                    $scope.showloading();
                    $scope.data = $scope.musics.slice(0, $scope.data.length + 10);
                    // $scope.$apply('data');
                    $scope.hideloading();
                     }



 })

 app.controller('VideoCtrl', function($scope,$sce, $ionicLoading) {
  $scope.getPostDetail = function(id){

    $.ajax({
          url: "http://rapcatchup.wpengine.com/api/get_post/",
          type: "get",
          data: {
             'post_id': id
          },
          dataType: 'html',
          success: function (response) {
          var object = JSON.parse(response);
          console.log('object');
          
          detail = object;
          console.log(detail);

          window.location.href = '#/app/postdetail';

          },
      error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);

      }
    });
  }

   $scope.showloading = function() {
    $ionicLoading.show({
      noBackdrop: true,
      template:'<p class="item-icon-left">Loading...<ion-spinner icon="ios"/></p>'
    });
  };

  $scope.hideloading = function(){
    $ionicLoading.hide();
  };

   //browseinapp
  $scope.viewMode = 'all';

  $scope.changeView = function(mode){
    $scope.viewMode = mode;
 
  }
  $scope.loadWeb = function(url) {
    console.log('loadWeb');
    $scope.changeView('one');
    $scope.webUrl = $sce.trustAsResourceUrl(url);
  }

  $scope.showloading();
            $.ajax({
                  url: "http://46.105.31.33/page-mobile-api.php",
                  type: "post",
                  data: {
                    'mobile_api_function':"get_post_video"
                  },
                  dataType: 'html',
                  success: function (response) {

                  var object = JSON.parse(response);
                  $scope.musics = object.posts;
                  console.log($scope.musics);
                  $ionicLoading.hide();
                  $scope.data = $scope.musics.slice(0, 10);
                  console.log("abc");
                  console.log($scope.data);
                  },
              error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
              }
            });

            $scope.getMoreData = function () {
                    // alert("aa");
                    $scope.showloading();
                    $scope.data = $scope.musics.slice(0, $scope.data.length + 10);
                    // $scope.$apply('data');
                    $scope.hideloading();
                     }


  
 })

 app.controller('BeefCtrl', function($scope,$sce, $ionicLoading) {
   //browseinapp
  $scope.getPostDetail = function(id){

    $.ajax({
          url: "http://rapcatchup.wpengine.com/api/get_post/",
          type: "get",
          data: {
             'post_id': id
          },
          dataType: 'html',
          success: function (response) {
          var object = JSON.parse(response);
          console.log('object');
          
          detail = object;
          console.log(detail);

          window.location.href = '#/app/postdetail';

          },
      error: function(jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);

      }
    });
  }

   $scope.showloading = function() {
    $ionicLoading.show({
      noBackdrop: true,
      template:'<p class="item-icon-left">Loading...<ion-spinner icon="ios"/></p>'
    });
  };

  $scope.hideloading = function(){
    $ionicLoading.hide();
  };

   //browseinapp
  $scope.viewMode = 'all';

  $scope.changeView = function(mode){
    $scope.viewMode = mode;
 
  }
  $scope.loadWeb = function(url) {
    console.log('loadWeb');
    $scope.changeView('one');
    $scope.webUrl = $sce.trustAsResourceUrl(url);
  }

  $scope.showloading();
            $.ajax({
                  url: "http://46.105.31.33/page-mobile-api.php",
                  type: "post",
                  data: {
                    'mobile_api_function':"get_post_beef"
                  },
                  dataType: 'html',
                  success: function (response) {

                  var object = JSON.parse(response);
                  $scope.beefs = object.posts;
                  console.log($scope.beefs);
                  $ionicLoading.hide();
                  $scope.data = $scope.beefs.slice(0, 10);
                  console.log("abc");
                  console.log($scope.data);
                  },
              error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
              }
            });

            $scope.getMoreData = function () {
                    // alert("aa");
                    $scope.showloading();
                    $scope.data = $scope.beefs.slice(0, $scope.data.length + 10);
                    // $scope.$apply('data');
                    $scope.hideloading();
                     }
 })


app.controller('PlaylistCtrl', function($scope, $stateParams) {
});
